//
// All rights reserved. by KeenKim 2022/12/01
//

import UIKit

class BookCell: UITableViewCell {

}
